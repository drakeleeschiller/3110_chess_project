let hours_worked = 30
