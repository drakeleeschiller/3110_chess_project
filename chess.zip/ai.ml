open State
open Pieces

(** random move generator*)
let random_move st =
  Random.self_init ();
  let moves_list = all_moves st in
  List.nth moves_list (Random.int (List.length moves_list))

let piece_value = function
  | Pawn -> 10
  | Knight | Bishop -> 30
  | Rook -> 50
  | Queen -> 90
  | King -> 900

let team_pieces team st =
  team_tiles team st |> List.split |> snd |> List.map Option.get
  |> List.map get_piece_type

let material_eval st =
  let rec material = function
    | [] -> 0
    | h :: t -> piece_value h + material t
  in
  material (team_pieces White st) - material (team_pieces Black st)

let eval st =
  if is_checkmate st then
    match st.turn with White -> -99999 | Black -> 99999
  else if is_stalemate st || insufficient_material st then 0
  else material_eval st

let sort_all_moves_by_eval st =
  all_moves st
  |> List.map (fun s -> (s, material_eval s))
  |> List.sort (fun s1 s2 -> compare (snd s1) (snd s2))

type 'a tree = T of 'a * 'a tree list

let rec moves_tree st depth =
  if depth = 0 then T ((st, eval st), [])
  else
    T
      ( (st, eval st),
        List.map (fun s -> moves_tree s (depth - 1)) (all_moves st) )

let is_leaf tree = match tree with T (_, []) -> true | _ -> false

let children tree =
  match tree with T (_, []) -> failwith "empty tree" | T (_, l) -> l

(** greedy 1-depth move optimization*)
let optimal_move_1_step st =
  let sorted_moves = sort_all_moves_by_eval st in
  match st.turn with
  | White -> sorted_moves |> List.rev |> List.hd |> fst
  | Black -> sorted_moves |> List.hd |> fst

let depth = 1

let get_state = function T ((s, e), _) -> s

let rand_cond () = Random.float 1.0 <= 0.2

(** uses the minimax algorithm to find the optimal move at a given depth*)
let optimal_move st =
  Random.self_init ();
  let rec minimax (tree : (State.t * 'b) tree) dep maxing =
    if depth = 0 || is_leaf tree then
      match tree with T ((s, e), _) -> (s, e)
    else if maxing then (
      let best_value = ref (-999999) in
      let best_move = ref None in
      let next_moves = children tree in
      List.iter
        (fun t ->
          let value = snd (minimax t (dep - 1) false) in
          if value > !best_value || (value = !best_value && rand_cond ())
          then (
            best_value := value;
            best_move := Some (get_state t))
          else ())
        next_moves;
      (Option.get !best_move, !best_value))
    else
      let best_value = ref 999999 in
      let best_move = ref None in
      let next_moves = children tree in
      List.iter
        (fun t ->
          let value = snd (minimax t (dep - 1) true) in
          if value < !best_value || (value = !best_value && rand_cond ())
          then (
            best_value := value;
            best_move := Some (get_state t))
          else ())
        next_moves;
      (Option.get !best_move, !best_value)
  in
  fst
    (match st.turn with
    | White -> minimax (moves_tree st depth) depth true
    | Black -> minimax (moves_tree st depth) depth false)
